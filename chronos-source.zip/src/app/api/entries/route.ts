import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { timeEntries, projects, tags, timeEntryTags } from "@/lib/db/schema";
import { eq, and, gte, lte, desc, inArray, isNotNull, type SQL } from "drizzle-orm";
import { whereTagsForLinkedUser } from "@/lib/tag-applicant";
import { z } from "zod";
import { getAccessibleUserIds } from "@/lib/permissions";
import { syncAndNotifyEntry } from "@/lib/entry-lifecycle";
import { setNotionLinkedTaskInProgressOnStop } from "@/lib/notion";
import { applicantIdForSessionLinkedUser, chronosUserIdFromSessionUser, resolveChronosUserIdForSessionUser } from "@/lib/chronos-session";
import { whereTimeEntriesForLinkedUser } from "@/lib/time-entry-applicant";
import { chronosEntryOwnerDisplayMap } from "@/lib/chronos-user-notion";

async function attachTags(
  entryRows: { id: string }[]
): Promise<Map<string, { id: string; name: string }[]>> {
  const map = new Map<string, { id: string; name: string }[]>();
  if (!db || entryRows.length === 0) return map;

  const entryIds = entryRows.map((e) => e.id);
  const rows = await db
    .select({ timeEntryId: timeEntryTags.timeEntryId, tagId: tags.id, tagName: tags.name })
    .from(timeEntryTags)
    .innerJoin(tags, eq(timeEntryTags.tagId, tags.id))
    .where(inArray(timeEntryTags.timeEntryId, entryIds));

  for (const r of rows) {
    const existing = map.get(r.timeEntryId) ?? [];
    existing.push({ id: r.tagId, name: r.tagName });
    map.set(r.timeEntryId, existing);
  }
  return map;
}

export async function GET(req: Request) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!db) return NextResponse.json({ entries: [] });

  const url = new URL(req.url);
  const limit = parseInt(url.searchParams.get("limit") ?? "50");
  const requestedUserId = url.searchParams.get("userId");
  const accessibleUserIds = await getAccessibleUserIds(session.user);
  const ownerChronosUserId =
    chronosUserIdFromSessionUser(session.user) ?? (await resolveChronosUserIdForSessionUser(session.user));
  const linkedApplicantId =
    applicantIdForSessionLinkedUser(session.user) ??
    (ownerChronosUserId && session.user.id !== ownerChronosUserId ? session.user.id : null);
  const requestedSelf = Boolean(
    requestedUserId &&
      ownerChronosUserId &&
      (requestedUserId === ownerChronosUserId || requestedUserId === linkedApplicantId)
  );
  const effectiveRequestedUserId = requestedSelf ? ownerChronosUserId : requestedUserId;

  const conditions: SQL[] = [isNotNull(timeEntries.stoppedAt)];

  if (accessibleUserIds !== null) {
    if (effectiveRequestedUserId && !accessibleUserIds.includes(effectiveRequestedUserId)) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }
    if (effectiveRequestedUserId) {
      conditions.push(
        requestedSelf && ownerChronosUserId
          ? whereTimeEntriesForLinkedUser(ownerChronosUserId, linkedApplicantId)
          : eq(timeEntries.userId, effectiveRequestedUserId)
      );
    } else if (ownerChronosUserId && accessibleUserIds.length === 1 && accessibleUserIds[0] === ownerChronosUserId) {
      conditions.push(whereTimeEntriesForLinkedUser(ownerChronosUserId, linkedApplicantId));
    } else if (accessibleUserIds.length === 1) {
      conditions.push(eq(timeEntries.userId, accessibleUserIds[0]));
    } else {
      conditions.push(inArray(timeEntries.userId, accessibleUserIds));
    }
  } else if (effectiveRequestedUserId) {
    conditions.push(
      requestedSelf && ownerChronosUserId
        ? whereTimeEntriesForLinkedUser(ownerChronosUserId, linkedApplicantId)
        : eq(timeEntries.userId, effectiveRequestedUserId)
    );
  }

  const from = url.searchParams.get("from");
  const to = url.searchParams.get("to");
  if (from) conditions.push(gte(timeEntries.startedAt, new Date(from)));
  if (to) conditions.push(lte(timeEntries.startedAt, new Date(to)));

  const rows = await db
    .select({
      entry: timeEntries,
      project: projects,
    })
    .from(timeEntries)
    .leftJoin(projects, eq(timeEntries.projectId, projects.id))
    .where(and(...conditions))
    .orderBy(desc(timeEntries.startedAt))
    .limit(limit);

  const [tagMap, ownerDisplayMap] = await Promise.all([
    attachTags(rows.map((r) => r.entry)),
    chronosEntryOwnerDisplayMap(rows.map((r) => ({ userId: r.entry.userId, applicantId: r.entry.applicantId ?? null }))),
  ]);

  const entries = rows.map(({ entry, project }) => ({
    ...entry,
    project,
    user:
      ownerDisplayMap.get(`${entry.userId}:${entry.applicantId ?? ""}`) ??
      (entry.userId ? { id: entry.userId, name: "Unknown", email: null } : null),
    tags: tagMap.get(entry.id) ?? [],
  }));

  return NextResponse.json({ entries });
}

const createSchema = z.object({
  projectId: z.string().uuid(),
  tagIds: z.array(z.string().uuid()).optional().default([]),
  description: z.string(),
  notionTaskPageId: z.string().optional().nullable(),
  notionTaskTitle: z.string().optional().nullable(),
  startedAt: z.string(),
  stoppedAt: z.string(),
  durationMs: z.number(),
});

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!db) return NextResponse.json({ error: "DB not available" }, { status: 503 });

  const chronosUserId = chronosUserIdFromSessionUser(session.user);
  if (!chronosUserId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid input" }, { status: 400 });

  const { tagIds, ...rest } = parsed.data;
  const uniqueTagIds = [...new Set(tagIds)];

  const flolabsId = applicantIdForSessionLinkedUser(session.user);
  if (uniqueTagIds.length > 0) {
    const valid = await db
      .select({ id: tags.id })
      .from(tags)
      .where(
        and(whereTagsForLinkedUser(chronosUserId, flolabsId), inArray(tags.id, uniqueTagIds))
      );
    if (valid.length !== uniqueTagIds.length) {
      return NextResponse.json({ error: "One or more tags are invalid" }, { status: 400 });
    }
  }

  const [entry] = await db
    .insert(timeEntries)
    .values({
      userId: chronosUserId,
      ...(flolabsId ? { flolabsId, applicantId: flolabsId } : {}),
      ...rest,
      startedAt: new Date(rest.startedAt),
      stoppedAt: new Date(rest.stoppedAt),
      notionTaskPageId: rest.notionTaskPageId ?? null,
      notionTaskTitle: rest.notionTaskTitle ?? null,
    })
    .returning();

  if (uniqueTagIds.length > 0) {
    await db
      .insert(timeEntryTags)
      .values(uniqueTagIds.map((tagId) => ({ timeEntryId: entry.id, tagId })))
      .onConflictDoNothing();
  }

  const createdTagMap = await attachTags([{ id: entry.id }]);
  const createdTags = createdTagMap.get(entry.id) ?? [];

  if (entry.stoppedAt) {
    await syncAndNotifyEntry(entry.id).catch(() => {});
  }
  if (entry.notionTaskPageId?.trim()) {
    void setNotionLinkedTaskInProgressOnStop(entry.notionTaskPageId).catch(() => {});
  }

  return NextResponse.json({ entry: { ...entry, tags: createdTags } }, { status: 201 });
}
