# GitHub Actions AWS deploy bootstrap

This sets up Chronos for AWS-native deploys on every push to `main`.

## What it creates

- GitHub OIDC provider in AWS (`token.actions.githubusercontent.com`)
- IAM role: `flolabs-chronos-github-actions-deploy`
- inline IAM policy allowing:
  - ECR push / digest lookup
  - App Runner update / describe / list-operations
- GitHub repo secrets for the Chronos workflow
- AWS SSM runtime secret source for DB / Redis / cron values used during deploy
- optional canary reset-password test settings for live verification

## Command

```powershell
powershell -ExecutionPolicy Bypass -File deploy/aws/setup-github-actions-deploy.ps1
```

## Inputs used

- `deploy/aws/provision-output.json`
- `.env.production.local` (fallback `.env.local`)

## GitHub secrets written

- `AUTH_SECRET`
- `NOTION_API_KEY`
- `NOTION_DATABASE_ID`
- `NOTION_ONBOARDINGS_DB_ID`
- `NOTION_TASKS_DB_ID`
- `NOTION_TEAMS_DB_ID`
- `NOTION_TEAM_MEMBERS_DB_ID`
- `RESEND_API_KEY`
- `EMAIL_FROM`

## Result

After this bootstrap succeeds, pushes to `main` can deploy Chronos without desktop Docker.

Routine deploys then use:
- GitHub Actions for build/push
- AWS OIDC for auth
- AWS SSM for DB / Redis / cron runtime values
- App Runner for rollout
- `/api/health` for live build verification

Optional `.env.production.local` / `.env.local` values that will also be mirrored to SSM when present:
- `RESET_PASSWORD_TEST_EMAIL`
- `RESET_PASSWORD_TEST_SECRET`

See `DEPLOYMENT.md` for the latest proven end-to-end method.
