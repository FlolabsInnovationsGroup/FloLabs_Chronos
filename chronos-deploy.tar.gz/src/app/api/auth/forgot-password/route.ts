import { NextResponse } from "next/server";
import crypto from "crypto";
import { db } from "@/lib/db";
import { passwordResetTokens, users } from "@/lib/db/schema";
import { and, eq, gt, isNull } from "drizzle-orm";
import { z } from "zod";
import { sendEmail } from "@/lib/mail";
import { normalizeEmail, resolvePublicAppOrigin } from "@/lib/invitations";
import { findApplicantForCredentialEmail } from "@/lib/applicant-auth";
import { addPrimaryEmailAlias, findUserByAnyEmail } from "@/lib/user-email-aliases";

const schema = z.object({ email: z.string().email() });

export async function POST(req: Request) {
  if (!db) return NextResponse.json({ error: "Database not available" }, { status: 503 });
  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Invalid input" }, { status: 400 });

  const email = normalizeEmail(parsed.data.email);
  const resetPasswordTestEmail = normalizeEmail(process.env.RESET_PASSWORD_TEST_EMAIL ?? "");
  const resetPasswordTestSecret = process.env.RESET_PASSWORD_TEST_SECRET?.trim() || null;
  const providedTestSecret = req.headers.get("x-reset-password-test-secret")?.trim() || null;
  const isAuthorizedResetPasswordTest =
    Boolean(resetPasswordTestSecret) &&
    Boolean(resetPasswordTestEmail) &&
    providedTestSecret === resetPasswordTestSecret &&
    email === resetPasswordTestEmail;

  const pipelineRow = await findApplicantForCredentialEmail(email);
  let applicant = pipelineRow
    ? {
        id: pipelineRow.id,
        email: pipelineRow.email,
        name: pipelineRow.name,
        status: pipelineRow.status,
        stage: pipelineRow.stage,
        isActive: pipelineRow.isActive,
      }
    : null;

  let user =
    pipelineRow &&
    (await db
      .select({ id: users.id, email: users.email, name: users.name, isActive: users.isActive })
      .from(users)
      .where(eq(users.id, pipelineRow.id))
      .limit(1))[0];

  if (!user && applicant?.email) {
    const byApplicantEmail = await findUserByAnyEmail(applicant.email.toLowerCase());
    if (byApplicantEmail) {
      user = {
        id: byApplicantEmail.id,
        email: byApplicantEmail.email,
        name: byApplicantEmail.name,
        isActive: byApplicantEmail.isActive,
      };
    }
  }
  if (!user) {
    const byRequestedEmail = await findUserByAnyEmail(email);
    if (byRequestedEmail) {
      user = {
        id: byRequestedEmail.id,
        email: byRequestedEmail.email,
        name: byRequestedEmail.name,
        isActive: byRequestedEmail.isActive,
      };
    }
  }

  if (!user) {
    console.info("[auth/forgot-password] reset skipped — no user found", {
      requestedEmail: email,
      applicantId: applicant?.id ?? null,
      applicantMatchedEmail: applicant?.email ?? null,
    });
    return NextResponse.json({ ok: true });
  }

  const recipientEmail = email;
  const recipientName = applicant?.name?.trim() || user.name;

  const [existing] = await db
    .select({ id: passwordResetTokens.id, token: passwordResetTokens.token, expiresAt: passwordResetTokens.expiresAt })
    .from(passwordResetTokens)
    .where(and(eq(passwordResetTokens.userId, user.id), isNull(passwordResetTokens.usedAt), gt(passwordResetTokens.expiresAt, new Date())))
    .limit(1);

  let tokenToSend = existing?.token ?? "";
  let tokenExpiresAt = existing?.expiresAt ?? new Date(0);
  let tokenRowId = existing?.id ?? "";
  let createdNewToken = false;

  if (existing) {
    if (isAuthorizedResetPasswordTest) {
      await db
        .update(passwordResetTokens)
        .set({ usedAt: new Date() })
        .where(eq(passwordResetTokens.id, existing.id));
    } else {
      tokenToSend = existing.token;
      tokenExpiresAt = existing.expiresAt;
      tokenRowId = existing.id;
    }
  }

  if (!existing || isAuthorizedResetPasswordTest) {
    const token = crypto.randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 2);
    const [createdReset] = await db
      .insert(passwordResetTokens)
      .values({ userId: user.id, token, expiresAt })
      .returning({ id: passwordResetTokens.id });
    tokenToSend = token;
    tokenExpiresAt = expiresAt;
    tokenRowId = createdReset.id;
    createdNewToken = true;
  }

  const resetUrl = `${resolvePublicAppOrigin(req.url)}/register?reset=${encodeURIComponent(tokenToSend)}`;

  try {
    const delivery = await sendEmail({
      to: recipientEmail,
      subject: "Reset your FloLabs Chronos password",
      text: `Hi ${recipientName},\n\nUse this link to reset your password: ${resetUrl}\n\nThis link expires in 2 hours.`,
      html: `<p>Hi ${recipientName},</p><p>Use this link to reset your password:</p><p><a href="${resetUrl}">${resetUrl}</a></p><p>This link expires in 2 hours.</p>`,
      headers: {
        "X-Chronos-Flow": "password-reset",
        "X-Chronos-User-Id": user.id,
      },
      tags: [
        { name: "flow", value: "password_reset" },
        { name: "app", value: "chronos" },
      ],
    });

    console.info("[auth/forgot-password] reset email accepted", {
      userId: user.id,
      applicantId: applicant?.id ?? null,
      email: recipientEmail,
      tokenId: tokenRowId,
      resendEmailId: delivery.id,
      isTest: isAuthorizedResetPasswordTest,
      cooldownResend: Boolean(existing && !isAuthorizedResetPasswordTest),
    });

    if (isAuthorizedResetPasswordTest) {
      return NextResponse.json({
        ok: true,
        test: {
          resendEmailId: delivery.id,
          resetToken: tokenToSend,
          expiresAt: tokenExpiresAt,
        },
      });
    }

    return NextResponse.json({
      ok: true,
      ...(existing && !isAuthorizedResetPasswordTest ? { cooldown: true, expiresAt: tokenExpiresAt } : {}),
    });
  } catch (error) {
    if (createdNewToken) {
      await db
        .update(passwordResetTokens)
        .set({ usedAt: new Date() })
        .where(eq(passwordResetTokens.id, tokenRowId));
    }

    console.error("[auth/forgot-password] reset email send failed", {
      userId: user.id,
      applicantId: applicant?.id ?? null,
      email: recipientEmail,
      tokenId: tokenRowId,
      isTest: isAuthorizedResetPasswordTest,
      error: error instanceof Error ? error.message : String(error),
    });

    if (isAuthorizedResetPasswordTest) {
      return NextResponse.json(
        {
          ok: false,
          error: error instanceof Error ? error.message : "Could not send reset email",
        },
        { status: 502 }
      );
    }

    return NextResponse.json({ ok: true });
  }
}
