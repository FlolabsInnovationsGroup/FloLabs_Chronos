"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSession } from "next-auth/react";
import { Badge } from "@/components/ui/Badge";
import { cn, formatDurationHuman, getCalendarWeekRangeLocal } from "@/lib/utils";
import type { Team, TimeEntry, User } from "@/types";
// User is used for teamMembersCache values

function formatRole(role: string) {
  return role === "team_lead" ? "Team Lead" : role === "admin" ? "Admin" : "Member";
}

function formatEntryDate(date: Date | string) {
  return new Date(date).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

/** Returns the ISO date string for N months ago from today (start of that day). */
function monthsAgo(n: number): string {
  const d = new Date();
  d.setMonth(d.getMonth() - n);
  d.setHours(0, 0, 0, 0);
  return d.toISOString().split("T")[0];
}

export default function TeamsPage() {
  const { data: session } = useSession();
  const isMember = session?.user.role === "member";

  const [teams, setTeams] = useState<Team[]>([]);
  // teamMembers is keyed by teamId and populated on-demand from /api/teams/[id]/members
  const [teamMembersCache, setTeamMembersCache] = useState<Record<string, User[]>>({});
  const [weeklyEntries, setWeeklyEntries] = useState<TimeEntry[]>([]);
  const [threeMonthEntries, setThreeMonthEntries] = useState<TimeEntry[]>([]);
  const [selectedTeamId, setSelectedTeamId] = useState<string | null>(null);
  const [selectedMemberId, setSelectedMemberId] = useState<string | null>(null);
  const [recentEntries, setRecentEntries] = useState<TimeEntry[]>([]);
  const [memberWeeklyEntries, setMemberWeeklyEntries] = useState<TimeEntry[]>([]);
  const [memberAllTimeEntries, setMemberAllTimeEntries] = useState<TimeEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [memberLoading, setMemberLoading] = useState(false);

  // Left panel controls
  const [teamSearch, setTeamSearch] = useState("");
  const [teamSortAsc, setTeamSortAsc] = useState(true);

  // Right panel controls
  const [memberSortAsc, setMemberSortAsc] = useState(true);

  const teamSearchRef = useRef<HTMLInputElement>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const { start, end } = getCalendarWeekRangeLocal();
      const from = start.toISOString().split("T")[0];
      const to = end.toISOString().split("T")[0];
      const threeMonthsFrom = monthsAgo(3);

      const [teamsRes, entriesRes, threeMonthRes] = await Promise.all([
        fetch("/api/teams", { cache: "no-store" }),
        fetch(`/api/entries?from=${from}&to=${to}&limit=1000`, { cache: "no-store" }),
        fetch(`/api/entries?from=${threeMonthsFrom}&to=${to}&limit=10000`, { cache: "no-store" }),
      ]);

      const teamsData = (await teamsRes.json()) as { teams?: Team[] };
      const entriesData = (await entriesRes.json()) as { entries?: TimeEntry[] };
      const threeMonthData = (await threeMonthRes.json()) as { entries?: TimeEntry[] };

      const fetchedTeams = teamsData.teams ?? [];
      setTeams(fetchedTeams);
      setWeeklyEntries(entriesData.entries ?? []);
      setThreeMonthEntries(threeMonthData.entries ?? []);

      setSelectedTeamId((prev) => {
        if (prev) return prev;
        return fetchedTeams[0]?.id ?? null;
      });
    } catch {
      // silently fail
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  useEffect(() => {
    if (!selectedMemberId) {
      setRecentEntries([]);
      setMemberWeeklyEntries([]);
      setMemberAllTimeEntries([]);
      return;
    }

    const { start, end } = getCalendarWeekRangeLocal();
    const from = start.toISOString().split("T")[0];
    const to = end.toISOString().split("T")[0];

    setMemberLoading(true);
    Promise.all([
      fetch(`/api/entries?userId=${selectedMemberId}&limit=3`, { cache: "no-store" }),
      fetch(`/api/entries?userId=${selectedMemberId}&from=${from}&to=${to}&limit=1000`, { cache: "no-store" }),
      fetch(`/api/entries?userId=${selectedMemberId}&limit=10000`, { cache: "no-store" }),
    ])
      .then(async ([recentRes, weeklyRes, allTimeRes]) => {
        const recentData = (await recentRes.json()) as { entries?: TimeEntry[] };
        const weeklyData = (await weeklyRes.json()) as { entries?: TimeEntry[] };
        const allTimeData = (await allTimeRes.json()) as { entries?: TimeEntry[] };
        setRecentEntries(recentData.entries ?? []);
        setMemberWeeklyEntries(weeklyData.entries ?? []);
        setMemberAllTimeEntries(allTimeData.entries ?? []);
      })
      .catch(() => {})
      .finally(() => setMemberLoading(false));
  }, [selectedMemberId]);

  // Fetch members for the selected team via /api/teams/[id]/members (works for all roles)
  useEffect(() => {
    if (!selectedTeamId) return;
    if (teamMembersCache[selectedTeamId]) return; // already loaded
    fetch(`/api/teams/${selectedTeamId}/members`, { cache: "no-store" })
      .then((r) => r.json())
      .then((data: { members?: User[] }) => {
        setTeamMembersCache((prev) => ({ ...prev, [selectedTeamId]: data.members ?? [] }));
      })
      .catch(() => {});
  }, [selectedTeamId, teamMembersCache]);

  const filteredSortedTeams = useMemo(() => {
    const q = teamSearch.trim().toLowerCase();
    const filtered = q ? teams.filter((t) => t.name.toLowerCase().includes(q)) : teams;
    return [...filtered].sort((a, b) => {
      const cmp = a.name.localeCompare(b.name);
      return teamSortAsc ? cmp : -cmp;
    });
  }, [teams, teamSearch, teamSortAsc]);

  const selectedTeam = useMemo(
    () => teams.find((t) => t.id === selectedTeamId) ?? null,
    [teams, selectedTeamId]
  );

  const rawTeamMembers = useMemo(() => {
    if (!selectedTeamId) return [];
    return teamMembersCache[selectedTeamId] ?? [];
  }, [teamMembersCache, selectedTeamId]);

  const teamMembers = useMemo(() => {
    return [...rawTeamMembers].sort((a, b) => {
      const cmp = a.name.localeCompare(b.name);
      return memberSortAsc ? cmp : -cmp;
    });
  }, [rawTeamMembers, memberSortAsc]);

  const selectedMember = useMemo(
    () => rawTeamMembers.find((u) => u.id === selectedMemberId) ?? null,
    [rawTeamMembers, selectedMemberId]
  );

  const teamStats = useMemo(() => {
    const activeMembers = rawTeamMembers.filter((u) => u.isActive);
    const liveCount = activeMembers.filter((u) => u.activeTimer?.startedAt).length;
    const teamUserIds = new Set(rawTeamMembers.map((u) => u.id));

    const weeklyMs = weeklyEntries
      .filter((e) => teamUserIds.has(e.userId))
      .reduce((sum, e) => sum + (e.durationMs ?? 0), 0);

    const avgTarget =
      activeMembers.length > 0
        ? activeMembers.reduce((sum, u) => sum + (u.weeklyTargetHours ?? 0), 0) / activeMembers.length
        : 0;

    // Average weekly hours over the past 3 months
    // We have ~13 weeks of data — compute total ms for team members then divide by 13
    const threeMonthMs = threeMonthEntries
      .filter((e) => teamUserIds.has(e.userId))
      .reduce((sum, e) => sum + (e.durationMs ?? 0), 0);
    const avgWeekly3Mo = threeMonthMs / 3_600_000 / 13; // 3 months ≈ 13 weeks

    return {
      activeMembers: activeMembers.length,
      liveCount,
      weeklyHours: weeklyMs / 3_600_000,
      avgTarget,
      avgWeekly3Mo,
    };
  }, [rawTeamMembers, weeklyEntries, threeMonthEntries]);

  const memberWeeklyHours = useMemo(
    () => memberWeeklyEntries.reduce((sum, e) => sum + (e.durationMs ?? 0), 0) / 3_600_000,
    [memberWeeklyEntries]
  );

  const memberAllTimeHours = useMemo(
    () => memberAllTimeEntries.reduce((sum, e) => sum + (e.durationMs ?? 0), 0) / 3_600_000,
    [memberAllTimeEntries]
  );

  function handleTeamSelect(teamId: string) {
    setSelectedTeamId(teamId);
    setSelectedMemberId(null);
  }

  function handleMemberClick(userId: string) {
    // Members can see the list but not individual performance cards.
    if (isMember) return;
    setSelectedMemberId((prev) => (prev === userId ? null : userId));
  }

  return (
    <div className="flex flex-col gap-6 max-w-[90rem] mx-auto h-full">
      <div>
        <h1
          className="text-2xl font-light italic text-on-background"
          style={{ fontFamily: "var(--font-newsreader, 'Newsreader'), serif" }}
        >
          Teams
        </h1>
        <p
          className="text-sm text-on-surface-variant mt-1"
          style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
        >
          View team performance and member activity.
        </p>
      </div>

      {loading ? (
        <div className="flex gap-6">
          <div className="w-64 shrink-0 space-y-2">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-12 rounded-xl bg-surface-container-low animate-pulse" />
            ))}
          </div>
          <div className="flex-1 h-64 rounded-xl bg-surface-container-low animate-pulse" />
        </div>
      ) : (
        /* Pin this row so the two columns can scroll independently */
        <div className="flex gap-6 items-start min-h-0" style={{ height: "calc(100vh - 12rem)" }}>

          {/* ── Left: scrollable team list ── */}
          <div className="w-64 shrink-0 flex flex-col gap-2 h-full">
            {/* Search + sort controls */}
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <span
                  className="material-symbols-outlined absolute left-2.5 top-1/2 -translate-y-1/2 text-outline-variant pointer-events-none"
                  style={{ fontSize: "15px" }}
                >
                  search
                </span>
                <input
                  ref={teamSearchRef}
                  type="text"
                  placeholder="Search teams…"
                  value={teamSearch}
                  onChange={(e) => setTeamSearch(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 text-sm text-on-background bg-surface-container-low rounded-xl outline-none focus:ring-2 focus:ring-primary/20 placeholder:text-outline-variant"
                  style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                />
              </div>
              <button
                type="button"
                title={teamSortAsc ? "Sort Z→A" : "Sort A→Z"}
                onClick={() => setTeamSortAsc((v) => !v)}
                className="shrink-0 w-8 h-8 flex items-center justify-center rounded-xl bg-surface-container-low text-on-surface-variant hover:text-primary hover:bg-surface-container transition-colors"
              >
                <span className="material-symbols-outlined" style={{ fontSize: "16px" }}>
                  {teamSortAsc ? "sort_by_alpha" : "sort"}
                </span>
              </button>
            </div>

            {/* Scrollable list */}
            <div className="flex-1 overflow-y-auto flex flex-col gap-1 pr-0.5">
              {filteredSortedTeams.length === 0 ? (
                <p
                  className="text-sm text-outline-variant px-3 py-4"
                  style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                >
                  No teams found.
                </p>
              ) : (
                filteredSortedTeams.map((team) => (
                  <button
                    key={team.id}
                    type="button"
                    onClick={() => handleTeamSelect(team.id)}
                    className={cn(
                      "w-full text-left px-4 py-3 rounded-xl text-sm transition-colors",
                      selectedTeamId === team.id
                        ? "bg-surface-container-high text-primary"
                        : "text-on-surface-variant hover:bg-surface-container-low hover:text-on-background"
                    )}
                    style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-medium truncate">{team.name}</span>
                      {!team.isActive && (
                        <Badge color="secondary" className="shrink-0 text-[10px]">
                          Inactive
                        </Badge>
                      )}
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>

          {/* ── Right: team dashboard or member card (independently scrollable) ── */}
          <div className="flex-1 min-w-0 h-full overflow-y-auto">
            {!selectedTeam ? (
              <div className="rounded-xl bg-surface-container-lowest paper-shadow p-8 text-center">
                <p
                  className="text-sm text-outline-variant"
                  style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                >
                  Select a team to see details.
                </p>
              </div>
            ) : selectedMember ? (
              /* ── Member performance card ── */
              <div className="rounded-xl bg-surface-container-lowest paper-shadow p-6 flex flex-col gap-6">
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div>
                    <button
                      type="button"
                      onClick={() => setSelectedMemberId(null)}
                      className="flex items-center gap-1.5 text-xs text-on-surface-variant hover:text-primary mb-3 transition-colors"
                      style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                    >
                      <span className="material-symbols-outlined" style={{ fontSize: "14px" }}>
                        arrow_back
                      </span>
                      Back to team
                    </button>
                    <h2
                      className="text-xl font-light italic text-on-background"
                      style={{ fontFamily: "var(--font-newsreader, 'Newsreader'), serif" }}
                    >
                      {selectedMember.name}
                    </h2>
                    <div className="flex items-center gap-2 mt-2 flex-wrap">
                      <Badge
                        color={
                          selectedMember.role === "admin"
                            ? "primary"
                            : selectedMember.role === "team_lead"
                              ? "secondary"
                              : "tertiary"
                        }
                      >
                        {formatRole(selectedMember.role)}
                      </Badge>
                      <Badge color={selectedMember.isActive ? "primary" : "secondary"}>
                        {selectedMember.isActive ? "Active" : "Inactive"}
                      </Badge>
                      {selectedMember.activeTimer?.startedAt && (
                        <Badge color="custom" className="bg-warm-muted text-error-dim">
                          Live
                        </Badge>
                      )}
                    </div>
                  </div>
                  {selectedMember.weeklyTargetHours != null && (
                    <div className="rounded-xl bg-surface-container-low px-4 py-3 text-right shrink-0">
                      <p
                        className="text-xs uppercase tracking-wide text-on-surface-variant"
                        style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                      >
                        Weekly Target
                      </p>
                      <p
                        className="text-xl font-light italic text-on-background mt-0.5"
                        style={{ fontFamily: "var(--font-newsreader, 'Newsreader'), serif" }}
                      >
                        {selectedMember.weeklyTargetHours}h
                      </p>
                    </div>
                  )}
                </div>

                {memberLoading ? (
                  <div className="h-24 rounded-xl bg-surface-container-low animate-pulse" />
                ) : (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="rounded-xl bg-surface-container-low p-4">
                        <p
                          className="text-xs uppercase tracking-wide text-on-surface-variant"
                          style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                        >
                          This Week
                        </p>
                        <p
                          className="text-2xl font-light italic text-on-background mt-1"
                          style={{ fontFamily: "var(--font-newsreader, 'Newsreader'), serif" }}
                        >
                          {memberWeeklyHours.toFixed(1)}h
                        </p>
                      </div>
                      <div className="rounded-xl bg-surface-container-low p-4">
                        <p
                          className="text-xs uppercase tracking-wide text-on-surface-variant"
                          style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                        >
                          All Time
                        </p>
                        <p
                          className="text-2xl font-light italic text-on-background mt-1"
                          style={{ fontFamily: "var(--font-newsreader, 'Newsreader'), serif" }}
                        >
                          {memberAllTimeHours.toFixed(1)}h
                        </p>
                      </div>
                    </div>

                    {recentEntries.length > 0 && (
                      <div>
                        <p
                          className="text-xs uppercase tracking-wide text-on-surface-variant mb-3"
                          style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                        >
                          Recent Entries
                        </p>
                        <div className="flex flex-col gap-2">
                          {recentEntries.map((entry) => (
                            <div
                              key={entry.id}
                              className="rounded-xl bg-surface-container-low px-4 py-3 flex items-start justify-between gap-4"
                            >
                              <div className="min-w-0">
                                {entry.project && (
                                  <p
                                    className="text-xs text-on-surface-variant mb-0.5"
                                    style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                                  >
                                    {entry.project.name}
                                  </p>
                                )}
                                <p
                                  className="text-sm text-on-background truncate"
                                  style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                                >
                                  {entry.description || (
                                    <span className="text-outline-variant italic">No description</span>
                                  )}
                                </p>
                                {entry.notionTaskTitle && (() => {
                                  const taskUrl = entry.notionTaskPageId
                                    ? `https://www.notion.so/${entry.notionTaskPageId.replace(/-/g, "")}`
                                    : null;
                                  return taskUrl ? (
                                    <a
                                      href={taskUrl}
                                      target="_blank"
                                      rel="noreferrer"
                                      className="inline-flex mt-1 max-w-full rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#755a40]/30"
                                    >
                                      <Badge
                                        color="custom"
                                        className="max-w-full min-w-0 bg-[#fed9b8] text-[#755a40] transition-colors hover:bg-[#f4ceb0]"
                                      >
                                        <span className="material-symbols-outlined mr-0.5 shrink-0" style={{ fontSize: "11px" }}>task</span>
                                        <span className="truncate" style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}>
                                          {entry.notionTaskTitle}
                                        </span>
                                      </Badge>
                                    </a>
                                  ) : (
                                    <Badge color="secondary" className="mt-1">
                                      <span className="material-symbols-outlined mr-0.5" style={{ fontSize: "11px" }}>task</span>
                                      {entry.notionTaskTitle}
                                    </Badge>
                                  );
                                })()}
                              </div>
                              <div className="text-right shrink-0">
                                <p
                                  className="text-sm font-medium text-on-background"
                                  style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                                >
                                  {entry.durationMs != null ? formatDurationHuman(entry.durationMs) : "—"}
                                </p>
                                <p
                                  className="text-xs text-outline-variant mt-0.5"
                                  style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                                >
                                  {formatEntryDate(entry.startedAt)}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </>
                )}
              </div>
            ) : (
              /* ── Team dashboard ── */
              <div className="flex flex-col gap-6">
                <div className="rounded-xl bg-surface-container-lowest paper-shadow p-6">
                  <div className="flex items-center gap-2 mb-1">
                    <p
                      className="text-xs uppercase tracking-wide text-on-surface-variant"
                      style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                    >
                      Team
                    </p>
                    <Badge color={selectedTeam.isActive ? "primary" : "secondary"}>
                      {selectedTeam.isActive ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                  <h2
                    className="text-xl font-light italic text-on-background"
                    style={{ fontFamily: "var(--font-newsreader, 'Newsreader'), serif" }}
                  >
                    {selectedTeam.name}
                  </h2>

                  <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-4 mt-5">
                    <div className="rounded-xl bg-surface-container-low p-4">
                      <p
                        className="text-xs uppercase tracking-wide text-on-surface-variant"
                        style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                      >
                        Members
                      </p>
                      <p
                        className="text-2xl font-light italic text-on-background mt-1"
                        style={{ fontFamily: "var(--font-newsreader, 'Newsreader'), serif" }}
                      >
                        {teamStats.activeMembers}
                      </p>
                    </div>
                    <div className="rounded-xl bg-surface-container-low p-4">
                      <p
                        className="text-xs uppercase tracking-wide text-on-surface-variant"
                        style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                      >
                        Live Now
                      </p>
                      <p
                        className="text-2xl font-light italic text-on-background mt-1"
                        style={{ fontFamily: "var(--font-newsreader, 'Newsreader'), serif" }}
                      >
                        {teamStats.liveCount}
                      </p>
                    </div>
                    <div className="rounded-xl bg-surface-container-low p-4">
                      <p
                        className="text-xs uppercase tracking-wide text-on-surface-variant"
                        style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                      >
                        This Week
                      </p>
                      <p
                        className="text-2xl font-light italic text-on-background mt-1"
                        style={{ fontFamily: "var(--font-newsreader, 'Newsreader'), serif" }}
                      >
                        {teamStats.weeklyHours.toFixed(1)}h
                      </p>
                    </div>
                    <div className="rounded-xl bg-surface-container-low p-4">
                      <p
                        className="text-xs uppercase tracking-wide text-on-surface-variant"
                        style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                      >
                        Avg Weekly (3 mo)
                      </p>
                      <p
                        className="text-2xl font-light italic text-on-background mt-1"
                        style={{ fontFamily: "var(--font-newsreader, 'Newsreader'), serif" }}
                      >
                        {teamStats.avgWeekly3Mo.toFixed(1)}h
                      </p>
                    </div>
                    <div className="rounded-xl bg-surface-container-low p-4">
                      <p
                        className="text-xs uppercase tracking-wide text-on-surface-variant"
                        style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                      >
                        Avg Target
                      </p>
                      <p
                        className="text-2xl font-light italic text-on-background mt-1"
                        style={{ fontFamily: "var(--font-newsreader, 'Newsreader'), serif" }}
                      >
                        {teamStats.avgTarget.toFixed(0)}h
                      </p>
                    </div>
                  </div>
                </div>

                {/* Member list */}
                <div className="rounded-xl bg-surface-container-lowest paper-shadow overflow-hidden">
                  <div className="px-5 py-4 border-b border-surface-container flex items-center justify-between gap-3">
                    <p
                      className="text-xs uppercase tracking-wide text-on-surface-variant font-semibold"
                      style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                    >
                      Members ({teamMembers.length})
                    </p>
                    <button
                      type="button"
                      title={memberSortAsc ? "Sort Z→A" : "Sort A→Z"}
                      onClick={() => setMemberSortAsc((v) => !v)}
                      className="flex items-center gap-1 text-xs text-on-surface-variant hover:text-primary transition-colors"
                      style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                    >
                      <span className="material-symbols-outlined" style={{ fontSize: "14px" }}>
                        {memberSortAsc ? "arrow_upward" : "arrow_downward"}
                      </span>
                      {memberSortAsc ? "A–Z" : "Z–A"}
                    </button>
                  </div>
                  {teamMembers.length === 0 ? (
                    <p
                      className="px-5 py-8 text-sm text-center text-outline-variant"
                      style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                    >
                      No members in this team.
                    </p>
                  ) : (
                    <div className="divide-y divide-surface-container">
                      {teamMembers.map((member) => (
                        <button
                          key={member.id}
                          type="button"
                          onClick={() => handleMemberClick(member.id)}
                          className={cn(
                            "w-full text-left px-5 py-4 transition-colors flex items-center justify-between gap-4",
                            isMember ? "cursor-default" : "hover:bg-surface-container-low cursor-pointer"
                          )}
                        >
                          <div className="min-w-0">
                            <p
                              className="text-sm font-medium text-on-background"
                              style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                            >
                              {member.name}
                            </p>
                            <p
                              className="text-xs text-outline-variant"
                              style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                            >
                              {member.email}
                            </p>
                            {(member.alternateEmails ?? []).filter((email) => email !== member.email).length > 0 ? (
                              <p
                                className="text-[11px] text-outline-variant mt-0.5"
                                style={{ fontFamily: "var(--font-work-sans, 'Work Sans'), sans-serif" }}
                              >
                                {`Also: ${(member.alternateEmails ?? []).filter((email) => email !== member.email).join(", ")}`}
                              </p>
                            ) : null}
                          </div>
                          <div className="flex items-center gap-2 shrink-0 flex-wrap justify-end">
                            <Badge
                              color={
                                member.role === "admin"
                                  ? "primary"
                                  : member.role === "team_lead"
                                    ? "secondary"
                                    : "tertiary"
                              }
                            >
                              {formatRole(member.role)}
                            </Badge>
                            <Badge color={member.isActive ? "primary" : "secondary"}>
                              {member.isActive ? "Active" : "Inactive"}
                            </Badge>
                            {member.activeTimer?.startedAt && (
                              <Badge color="custom" className="bg-warm-muted text-error-dim">
                                Live
                              </Badge>
                            )}
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
